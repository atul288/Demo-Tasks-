define('Application', ['SC.Models.Init', 'Configuration', 'Utils', 'Console'], function(
    ModelsInit,
    Configuration,
    Utils,
    Console
) {});
