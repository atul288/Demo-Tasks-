define('DependencyMap4', ['DependencyMap1'], function() {});
