define('EntryPointError', ['NotExistingDependency'], function() {});
