define(['Dependency2'], function() {});
