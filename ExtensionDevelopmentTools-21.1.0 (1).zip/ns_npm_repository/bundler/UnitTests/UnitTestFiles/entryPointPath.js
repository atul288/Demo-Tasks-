define('EntryPointPath', ['DependencyPath'], function() {});
