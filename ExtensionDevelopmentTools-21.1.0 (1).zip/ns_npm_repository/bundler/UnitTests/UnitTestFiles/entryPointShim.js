define('EntryPointShim', ['DependencyShim'], function() {});
