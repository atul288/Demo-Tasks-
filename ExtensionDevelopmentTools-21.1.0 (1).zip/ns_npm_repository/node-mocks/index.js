module.exports = {
    mockChild_process: require('./modules/child_processMock'),
    mockCrypto: require('./modules/cryptoMock'),
    mockExpress: require('./modules/expressMock'),
    mockFs: require('./modules/fsMock'),
    mockHttps: require('./modules/httpsMock'),
    mockOs: require('./modules/osMock'),
    mockPath: require('./modules/pathMock'),
    mockQuerystring: require('./modules/querystringMock'),
    mockUrl: require('./modules/urlMock')
}
